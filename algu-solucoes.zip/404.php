<? require_once('header.php') ?>
    <div class="container-404">
        <div class="container-mensagem-404">
            <div class="container">
                <h1>Essa página não existe. Navegue pelos nossos menus.</h1>
            </div>
        </div>

        <div class="container">
            <img class="img-responsive" src="imagens/outras/404.jpg" alt="404" title="Página não encontrada!"/>
        </div>

    </div>
<? require_once('footer.php') ?>