<? require_once('header.php') ?>

<section class="servicos-container">
    <div class="container">

        <div class="jumbotron">
            <h2><strong>Criação de Sites</strong></h2>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae cumque deleniti doloremque doloribus
                laboriosam necessitatibus veniam! Aliquid assumenda ducimus esse excepturi fugit hic magnam sunt.
                Assumenda distinctio id ipsa voluptatibus!
            </p>
            <p>
                A inventore molestiae quae vero? A consequuntur deserunt, ducimus enim, illum nam natus officia
                praesentium quae quaerat soluta tempora tempore, vero voluptatibus!
            </p>
           <p>
                <img class="img-responsive" src="imagens/servicos/servico-criacao-sites.png" alt="Criação de Sites Responsivos"
                     title="Criação de Sites conforme sua necessidade"/>
           </p>
        </div>

        <div class="jumbotron">
            <h2><strong>Criação de Sistemas Web e Desktop</strong></h2>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae cumque deleniti doloremque doloribus
                laboriosam necessitatibus veniam! Aliquid assumenda ducimus esse excepturi fugit hic magnam sunt.
                Assumenda distinctio id ipsa voluptatibus!
            </p>
            <p>
                A inventore molestiae quae vero? A consequuntur deserunt, ducimus enim, illum nam natus officia
                praesentium quae quaerat soluta tempora tempore, vero voluptatibus!
            </p>
            <p>
                <img class="img-responsive" src="imagens/servicos/sistemas-servicos.png" alt="Criação de Sistemas Web e Desktop"
                     title="Desenvolvemos Sistemas Web e Desktop para o seu problema"/>
            </p>
        </div>

        <div class="jumbotron">
            <h2><strong>Redes Sociais</strong></h2>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae cumque deleniti doloremque doloribus
                laboriosam necessitatibus veniam! Aliquid assumenda ducimus esse excepturi fugit hic magnam sunt.
                Assumenda distinctio id ipsa voluptatibus!
            </p>
            <p>
                A inventore molestiae quae vero? A consequuntur deserunt, ducimus enim, illum nam natus officia
                praesentium quae quaerat soluta tempora tempore, vero voluptatibus!
            </p>
            <p>
                <img class="img-responsive" src="imagens/servicos/redes-sociais.png" alt="Integração com as Redes Sociais"
                     title="Cuidamos da suas Redes Sociais"/>
            </p>
        </div>

    </div>
</section>

<? require_once('footer.php') ?>