<? require_once ('header.php') ?>

<section class="empresa-container">
    <div class="banner-container">
        <article class="container">
            <h1>QUEM SOMOS</h1>
        </article>
    </div>

    <div class="quem-somos-container">
        <article class="container">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        EMPRESA
                    </h3>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-9">
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi asperiores atque consequatur dolor
                                ducimus eius eos illum ipsa, libero maxime nam nisi officia pariatur quod rerum sed vel, vero.
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad blanditiis eveniet minus, obcaecati
                                praesentium quos rerum ullam. At excepturi harum laborum molestiae non! Consequatur dolore eaque
                                molestias possimus veniam! Reprehenderit!
                            </p>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi asperiores atque consequatur dolor
                                ducimus eius eos illum ipsa, libero maxime nam nisi officia pariatur quod rerum sed vel, vero.
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad blanditiis eveniet minus, obcaecati
                                praesentium quos rerum ullam. At excepturi harum laborum molestiae non! Consequatur dolore eaque
                                molestias possimus veniam! Reprehenderit!
                            </p>
                        </div>
                        <div class="col-md-3">
                            <img src="imagens/content/ag-solucoes.png" alt="Algu Soluções" title="Algu Soluções"/>
                        </div>
                    </div>
                </div>
            </div>

            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        MISSÃO E VISÃO
                    </h3>
                </div>
                <div class="panel-body">
                    <h3>MISSÃO</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi asperiores atque consequatur dolor
                        ducimus eius eos illum ipsa, libero maxime nam nisi officia pariatur quod rerum sed vel, vero.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    </p>
                    <h3>VISÃO</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi asperiores atque consequatur dolor
                        ducimus eius eos illum ipsa.
                    </p>
                </div>
            </div>

        </article>
    </div>



</section>






<hr/>
<? require_once('footer.php') ?>