<? require_once ('header.php') ?>

<section class="principal-container">

    <div class="foco-container">
        <article class="container">
            <h1>NOSSO FOCO: <strong>SATISFAÇÃO DOS CLIENTES!</strong></h1>
            <h4>SEU SISTEMA COM SUAS NECESSIDADES.</h4>
           <!-- <p>CONHEÇA A <strong>AUGU SOLUÇÕES!</strong></p> -->
        </article>
    </div>

    <div class="servicos-container">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-4">
                    <div class="thumbnail">
                        <img src="imagens/content/criacao-sites.png" alt="Criação de Sites" title="Seu site com sua cara!">
                        <div class="caption">
                            <h3>Criação de Sites</h3>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus beatae cupiditate,
                                dolores, eaque earum error ex iusto magnam modi non numquam quaerat quia ratione saepe
                                suscipit, tempore unde! Asperiores, corporis.
                            </p>
                            <p><a href="#" class="btn btn-primary" role="button">+INFORMAÇÕES</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="thumbnail">
                        <img src="imagens/content/criacao-sistemas.png" alt="Criação de Sistemas" title="Sistemas para suas necessidades">
                        <div class="caption">
                            <h3>Criação de Sistemas</h3>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci asperiores
                                consectetur distinctio dolores ipsum ullam velit veritatis! Aspernatur dolorum ex
                                facilis fugiat mollitia placeat quos unde veniam vitae, voluptas. Et!
                            </p>
                            <p><a href="#" class="btn btn-primary" role="button">+INFORMAÇÕES</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="thumbnail">
                        <img src="imagens/content/redes-sociais.png" alt="Redes Sociais" title="Integração com as redes sociais">
                        <div class="caption">
                            <h3>Redes Sociais</h3>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda cupiditate
                                exercitationem incidunt ipsam, maxime voluptatibus. Animi consequatur dolor ea harum
                                natus nisi odio quis sit veniam vitae! Alias iure, non!
                            </p>
                            <p><a href="#" class="btn btn-primary" role="button">+INFORMAÇÕES</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<hr/>
<? require_once('footer.php') ?>