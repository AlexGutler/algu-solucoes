
<footer  class="rodape-container">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="copyright">
                    <p>
                        Todos os Direitos Reservados -
                        <?
                            date_default_timezone_set('UTC');
                            echo date("Y");
                        ?>
                    </p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="media-social">
                    <p>
                        <a href="#"  target="_blank"><img src="imagens/icons/icon-facebook.png" alt="Facebook" title="Algu no Facebook"></a>
                        <a href="#"  target="_blank"><img src="imagens/icons/icon-twitter.png" alt="Twitter"></a>
                        <a href="#"  target="_blank"><img src="imagens/icons/icon-youtube.png" alt="Youtube"></a>
                        <a href="#"  target="_blank"><img src="imagens/icons/icon-pinterest.png" alt="Pinterest"></a>
                        <a href="#"  target="_blank"><img src="imagens/icons/icon-github.png" alt="Github"></a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer>

</body>
</html>